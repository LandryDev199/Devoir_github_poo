package m2i;

import bean.Personne;
import java.io.IOException;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/home")
public class Home extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Personne user = new Personne();
        HttpSession maSession = request.getSession();
        user = (Personne) maSession.getAttribute("utilisateur");
        System.out.println(user);
        if (user == null) {
            RequestDispatcher dispatcher = request.getRequestDispatcher("/login");
            dispatcher.forward(request, response);
        }
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/resultatLogin.jsp");
        dispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        traitement(request, response);
    }

    protected void traitement(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Personne user = new Personne();
        HttpSession maSession = request.getSession();

        // Etape 1 : Recuperation des parametres de la requete
        String login = request.getParameter("loginuser");
        String pwd = request.getParameter("mdpuser");

        // Etape 2 : Soumettre les parametres de la requete
        user = new Personne(login, pwd);

        maSession.setAttribute("utilisateur", user);

        // Etape 3 : Reponse a l'utilisateur
        RequestDispatcher dispatcher = request.getRequestDispatcher("/WEB-INF/resultatLogin.jsp");
        dispatcher.forward(request, response);

    }
}
