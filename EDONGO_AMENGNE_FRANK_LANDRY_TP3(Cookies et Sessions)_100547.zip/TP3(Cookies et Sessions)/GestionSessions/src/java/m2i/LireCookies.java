/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package m2i;

import java.io.IOException;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Cookie;

public class LireCookies extends HttpServlet {
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Cree et recupere un tableau de cookies pour le domaine
        Cookie[] cookies = request.getCookies();

        if (cookies != null) {
            StringBuffer cookiesTrouves = new StringBuffer("<h2>Cookie(s) trouve(s)</h2>");

            for (Cookie cookie : cookies) {
                cookiesTrouves.append("Nom : ").append(cookie.getName()).append(",  ");
                cookiesTrouves.append("Valeur: ").append(cookie.getValue()).append(" <br/>");
            }
            request.setAttribute("attrCookiesTrouves", cookiesTrouves);
        } else {
            request.setAttribute("attrCookiesTrouves", "Aucun cookie trouve");
        }
        request.setAttribute("titre", "Lecture des cookies");
        RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/affichagecookies.jsp");
        rd.forward(request, response);
    }
}
